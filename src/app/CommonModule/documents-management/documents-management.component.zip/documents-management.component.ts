import { filter } from 'rxjs/operators';
import { DocumentService } from './../../Services/document.service';
import { Component, OnInit, AfterViewInit } from '@angular/core';
import * as $ from 'jquery';
import { CategoryOfDocument } from '../../Models/Misc/CategoryOfDocument';
@Component({
  selector: 'ngx-documents-management',
  templateUrl: './documents-management.component.html',
  styleUrls: ['./documents-management.component.scss']
})
export class DocumentsManagementComponent implements OnInit,AfterViewInit {
  ngAfterViewInit(): void {
        $("#open").click(function() {
          $(".flipper").toggleClass("flipped");
          $(".avatar").toggleClass("small");
          $(".small-name").toggleClass("small");
          $('input.subject').focus();
          $(".buttons.large").toggleClass("hide");
      });
      
      // transitions for the cancel button
      $('#cancel').click(function() {
          $(".flipper").toggleClass("flipped");
          $(".avatar").toggleClass("small");
          $(".small-name").toggleClass("small");
          $(".buttons.large").toggleClass("hide");
      })
      
   
  }

  constructor(private documentService:DocumentService) { }
      
  evidenceCategories:Array<CategoryOfDocument>;
  root:CategoryOfDocument=new CategoryOfDocument();
  nodes;any;
  ngOnInit() {
    
    this.getNodes();


  }
  currentItem:any;
  getCategories(){
    this.documentService.getEvidenceCategories().subscribe(result=>{

      // for (let index = 0; index < result.length; index++) {
      //   const element = result[index];
      //   let categoryOfDocument:CategoryOfDocument;
      //   categoryOfDocument.id=element.id;
      //   categoryOfDocument.categoryId=element.categoryId;
      //   categoryOfDocument.name=element.name;
      //   this.evidenceCategories.push()
      // }
      this.root.name=result.find(x=>x.categoryId==0).name;
       this.evidenceCategories=result.filter(x=>x.categoryId!=0);

    

     
    //   for (let index = 0; index < evidenceCategoriesCollection.length; index++) {
    //     let element = evidenceCategoriesCollection[index];
    //      this.nodes=result.filter(x=>x.evidence.categoryId==element.id)
        
    //  }

    })
  }

  allNodes:any;
  getNodes(){
    this.documentService.getEvidenceNodes().subscribe(result=>{
      this.allNodes=result;
      this.getCategories();
    });


  } 

}
